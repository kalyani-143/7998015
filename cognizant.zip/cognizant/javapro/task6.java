public class task6 {
    public static void main(String[] args) {
        int number = 42;
        float decimalFloat = 3.14f;
        double decimalDouble = 9.81;
        char letter = 'A';
        boolean isJavaFun = true;

        System.out.println("int value: " + number);
        System.out.println("float value: " + decimalFloat);
        System.out.println("double value: " + decimalDouble);
        System.out.println("char value: " + letter);
        System.out.println("boolean value: " + isJavaFun);
    }
}
