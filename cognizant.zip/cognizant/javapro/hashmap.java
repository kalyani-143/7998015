import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class hashmap {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Map<Integer, String> studentMap = new HashMap<>();

        System.out.print("How many students do you want to add? ");
        int count = scanner.nextInt();

        for (int i = 0; i < count; i++) {
            System.out.print("Enter student ID: ");
            int id = scanner.nextInt();
            scanner.nextLine(); // consume newline
            System.out.print("Enter student name: ");
            String name = scanner.nextLine();
            studentMap.put(id, name);
        }

        System.out.print("Enter an ID to look up: ");
        int lookupId = scanner.nextInt();

        if (studentMap.containsKey(lookupId)) {
            System.out.println("Student name: " + studentMap.get(lookupId));
        } else {
            System.out.println("No student found with ID " + lookupId);
        }

        System.out.println("\nAll student entries:");
        for (Map.Entry<Integer, String> entry : studentMap.entrySet()) {
            System.out.println("ID " + entry.getKey() + " -> " + entry.getValue());
        }

        scanner.close();
    }
}
