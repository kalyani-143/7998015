import java.util.Scanner;

public class string {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter a string: ");
        String input = scanner.nextLine();

        // Method 1: Using StringBuilder
        String reversed = new StringBuilder(input).reverse().toString();

        System.out.println("Original string: " + input);
        System.out.println("Reversed string: " + reversed);

        scanner.close();
    }
}
