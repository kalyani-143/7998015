class OperatorPrecedence8 {
    public static void main(String[] args) {
        int result1 = 10 + 5 * 2; // multiplication before addition
        int result2 = (10 + 5) * 2; // parentheses change order
        int result3 = 20 / 2 + 3; // division before addition
        int result4 = 20 / (2 + 3); // parentheses first, then division

        System.out.println("Expression: 10 + 5 * 2");
        System.out.println("Result: " + result1);
        System.out.println("Explanation: 5 * 2 = 10, then 10 + 10 = 20\n");

        System.out.println("Expression: (10 + 5) * 2");
        System.out.println("Result: " + result2);
        System.out.println("Explanation: parentheses evaluated first: 10 + 5 = 15, then 15 * 2 = 30\n");

        System.out.println("Expression: 20 / 2 + 3");
        System.out.println("Result: " + result3);
        System.out.println("Explanation: division before addition: 20 / 2 = 10, then 10 + 3 = 13\n");

        System.out.println("Expression: 20 / (2 + 3)");
        System.out.println("Result: " + result4);
        System.out.println("Explanation: parentheses first: 2 + 3 = 5, then 20 / 5 = 4");
    }
}
