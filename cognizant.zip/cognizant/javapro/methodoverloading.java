public class methodoverloading {
    // Method 1: Add two integers
    public static int add(int a, int b) {
        return a + b;
    }

    // Method 2: Add two doubles
    public static double add(double a, double b) {
        return a + b;
    }

    // Method 3: Add three integers
    public static int add(int a, int b, int c) {
        return a + b + c;
    }

    public static void main(String[] args) {
        System.out.println("Method Overloading Example\n");

        // Calling add with two integers
        int result1 = add(5, 10);
        System.out.println("add(5, 10) = " + result1);

        // Calling add with two doubles
        double result2 = add(5.5, 10.3);
        System.out.println("add(5.5, 10.3) = " + result2);

        // Calling add with three integers
        int result3 = add(5, 10, 15);
        System.out.println("add(5, 10, 15) = " + result3);
    }
}
