class MessagePrinter implements Runnable {
    private String message;

    public MessagePrinter(String message) {
        this.message = message;
    }

    @Override
    public void run() {
        for (int i = 1; i <= 5; i++) {
            System.out.println(message + " - Count: " + i);
        }
    }
}

public class ThreadDemo {
    public static void main(String[] args) {
        MessagePrinter task1 = new MessagePrinter("Thread 1 is running");
        MessagePrinter task2 = new MessagePrinter("Thread 2 is running");

        Thread t1 = new Thread(task1);
        Thread t2 = new Thread(task2);

        t1.start();
        t2.start();
    }
}