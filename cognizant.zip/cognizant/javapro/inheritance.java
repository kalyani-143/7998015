public class inheritance {
    // Base class Animal
    static class Animal {
        void makeSound() {
            System.out.println("Animal makes a sound");
        }
    }

    // Subclass Dog that extends Animal
    static class Dog extends Animal {
        @Override
        void makeSound() {
            System.out.println("Dog barks: Woof! Woof!");
        }
    }

    public static void main(String[] args) {
        // Create an Animal object
        Animal animal = new Animal();
        System.out.println("Animal:");
        animal.makeSound();
        System.out.println();

        // Create a Dog object
        Dog dog = new Dog();
        System.out.println("Dog:");
        dog.makeSound();
        System.out.println();

        // Demonstrate polymorphism
        Animal dog2 = new Dog();
        System.out.println("Animal reference pointing to Dog:");
        dog2.makeSound();
    }
}
