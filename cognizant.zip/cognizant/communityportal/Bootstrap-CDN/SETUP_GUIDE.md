# Bootstrap 5 Setup Exercises - Complete Guide

## Exercise 1.1: Bootstrap 5 via CDN

### Overview

This exercise demonstrates linking Bootstrap 5 directly from a Content Delivery Network (CDN).

### Files

- `index.html` - Main file with Bootstrap 5 linked via CDN

### Key Features Demonstrated

- **CDN Links**: Bootstrap CSS and JS Bundle from jsDelivr CDN
- **Responsive Navbar**: Collapsible navigation menu
- **Card Components**: Bootstrap card styling
- **Alert Components**: Dismissible alerts
- **Grid System**: 12-column responsive layout
- **Buttons**: Various Bootstrap button styles
- **Utility Classes**: Spacing, colors, text alignment

### CDN Links Used

```html
<!-- Bootstrap 5 CSS -->
<link
  href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css"
  rel="stylesheet"
/>

<!-- Bootstrap 5 JS Bundle (includes Popper.js) -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
```

### Advantages of CDN Approach

✓ No installation needed
✓ No build process required
✓ Simple and quick setup
✓ Content is cached across multiple sites
✓ Reduced bandwidth from your server

### Disadvantages

✗ Requires internet connection
✗ No offline access
✗ Limited customization
✗ Dependency on external CDN availability

---

## Exercise 1.2: Bootstrap 5 with npm Setup

### Overview

This exercise demonstrates setting up Bootstrap 5 locally using npm, allowing full customization and offline development.

### Files

- `exercise-1-2-npm-setup.html` - Sample page using local Bootstrap files
- `package.json` - Project dependencies and scripts

### Installation Steps

#### Step 1: Initialize npm Project

```bash
npm init -y
```

#### Step 2: Install Bootstrap

```bash
npm install bootstrap@5.3.0
```

This will:

- Create `node_modules/` folder with Bootstrap files
- Add Bootstrap to `package.json` dependencies

#### Step 3: Project Structure

```
your-project/
├── index.html
├── package.json
├── node_modules/
│   └── bootstrap/
│       ├── dist/
│       │   ├── css/
│       │   │   └── bootstrap.min.css
│       │   └── js/
│       │       └── bootstrap.bundle.min.js
│       └── scss/
└── scss/
    └── custom.scss
```

#### Step 4: Link Bootstrap Files in HTML

```html
<!-- Link CSS from node_modules -->
<link
  rel="stylesheet"
  href="./node_modules/bootstrap/dist/css/bootstrap.min.css"
/>

<!-- Link JS from node_modules -->
<script src="./node_modules/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
```

### Optional: Custom SCSS Setup

#### Install Sass

```bash
npm install --save-dev sass
```

#### Create Custom SCSS File (scss/custom.scss)

```scss
// 1. Include functions first (so you can manipulate colors, SVGs, calc, etc)
@import "../node_modules/bootstrap/scss/functions";

// 2. Override Bootstrap's default variables here
$primary-color: #667eea;
$secondary-color: #764ba2;

// 3. Include the remainder of Bootstrap
@import "../node_modules/bootstrap/scss/variables";
@import "../node_modules/bootstrap/scss/mixins";
@import "../node_modules/bootstrap/scss/root";
@import "../node_modules/bootstrap/scss/reboot";
// ... include other Bootstrap files as needed
@import "../node_modules/bootstrap/scss/containers";
@import "../node_modules/bootstrap/scss/grid";
@import "../node_modules/bootstrap/scss/tables";
@import "../node_modules/bootstrap/scss/forms";
@import "../node_modules/bootstrap/scss/buttons";
@import "../node_modules/bootstrap/scss/transitions";
@import "../node_modules/bootstrap/scss/dropdown";
@import "../node_modules/bootstrap/scss/button-group";
@import "../node_modules/bootstrap/scss/nav";
@import "../node_modules/bootstrap/scss/navbar";
@import "../node_modules/bootstrap/scss/card";
@import "../node_modules/bootstrap/scss/accordion";
@import "../node_modules/bootstrap/scss/breadcrumb";
@import "../node_modules/bootstrap/scss/pagination";
@import "../node_modules/bootstrap/scss/badge";
@import "../node_modules/bootstrap/scss/alert";
@import "../node_modules/bootstrap/scss/progress";
@import "../node_modules/bootstrap/scss/list-group";
@import "../node_modules/bootstrap/scss/close";
@import "../node_modules/bootstrap/scss/toasts";
@import "../node_modules/bootstrap/scss/modal";
@import "../node_modules/bootstrap/scss/tooltip";
@import "../node_modules/bootstrap/scss/popover";
@import "../node_modules/bootstrap/scss/carousel";
@import "../node_modules/bootstrap/scss/spinners";
@import "../node_modules/bootstrap/scss/offcanvas";
@import "../node_modules/bootstrap/scss/placeholders";
@import "../node_modules/bootstrap/scss/helpers";

// 4. Add custom styles here
body {
  font-family: "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;
}
```

#### Update package.json Scripts

```json
{
  "scripts": {
    "sass": "sass scss:css",
    "sass:watch": "sass --watch scss:css",
    "start": "npm run sass:watch"
  }
}
```

#### Compile SCSS

```bash
npm run sass
```

### Advantages of npm Approach

✓ Full customization via SCSS
✓ Offline development
✓ Version control of dependencies
✓ Build tools integration
✓ Can be bundled with other tools (Webpack, Vite, etc.)
✓ Easy updates with `npm update`

### Disadvantages

✗ Requires Node.js installation
✗ Additional setup and build process
✗ More files to manage

---

## Key Bootstrap Components Used

### 1. Navbar

```html
<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <!-- Navbar content -->
</nav>
```

### 2. Container & Grid

```html
<div class="container">
  <div class="row">
    <div class="col-md-4">Column 1</div>
    <div class="col-md-4">Column 2</div>
    <div class="col-md-4">Column 3</div>
  </div>
</div>
```

### 3. Cards

```html
<div class="card">
  <div class="card-header">Header</div>
  <div class="card-body">
    <h5 class="card-title">Title</h5>
    <p class="card-text">Content</p>
  </div>
</div>
```

### 4. Forms

```html
<form>
  <div class="mb-3">
    <label for="email" class="form-label">Email</label>
    <input type="email" class="form-control" id="email" />
  </div>
  <button type="submit" class="btn btn-primary">Submit</button>
</form>
```

### 5. Buttons

```html
<button class="btn btn-primary">Primary</button>
<button class="btn btn-success">Success</button>
<button class="btn btn-danger">Danger</button>
```

### 6. Alerts

```html
<div class="alert alert-success alert-dismissible fade show">
  Success message here
  <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
```

---

## Running the Projects

### Exercise 1.1 (CDN)

- Simply open `index.html` in a web browser
- No installation or build process required

### Exercise 1.2 (npm)

Option 1: Direct File Access

```bash
# Navigate to the Bootstrap-CDN folder and open exercise-1-2-npm-setup.html
```

Option 2: Using Live Server (Recommended)

```bash
npm install -g live-server
live-server
```

Option 3: Using Python HTTP Server

```bash
python -m http.server 8000
```

Then visit: `http://localhost:8000`

---

## Additional Resources

- **Bootstrap Documentation**: https://getbootstrap.com/docs/5.3/
- **Bootstrap Components**: https://getbootstrap.com/docs/5.3/components/
- **Bootstrap Utilities**: https://getbootstrap.com/docs/5.3/utilities/
- **CDN Providers**: jsDelivr, cdnjs, BootstrapCDN

## Comparison Table

| Feature           | CDN     | npm              |
| ----------------- | ------- | ---------------- |
| Setup Time        | Seconds | Minutes          |
| Customization     | Limited | Full             |
| Offline Access    | No      | Yes              |
| Internet Required | Yes     | No (after setup) |
| Version Control   | Manual  | Automatic        |
| Build Tools       | No      | Yes              |
| Performance       | Good    | Excellent        |

---

Happy coding with Bootstrap 5! 🚀
