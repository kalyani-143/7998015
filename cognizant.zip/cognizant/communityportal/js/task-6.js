const events = [
  { name: "Music Festival", category: "Music", date: "2026-07-20" },
  { name: "Art Workshop", category: "Art", date: "2026-08-10" },
  { name: "Coding Meetup", category: "Tech", date: "2026-09-05" },
];

// Add new events using push()
events.push({
  name: "Baking Workshop",
  category: "Workshop",
  date: "2026-10-12",
});
events.push({ name: "Jazz Night", category: "Music", date: "2026-11-02" });

console.log("All events:", events);

// Show only music events using filter()
const musicEvents = events.filter((event) => event.category === "Music");
console.log("Music events:", musicEvents);

// Format display cards using map()
const eventCards = events.map((event) => `${event.category} on ${event.name}`);
console.log("Display cards:", eventCards);
