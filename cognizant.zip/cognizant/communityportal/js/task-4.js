const events = [
  { name: "Music Festival", date: "2026-07-20", seats: 50, category: "Music" },
  { name: "Art Workshop", date: "2026-08-10", seats: 25, category: "Workshop" },
  { name: "Coding Meetup", date: "2026-09-05", seats: 30, category: "Tech" },
];

const registrations = [];

function addEvent(event) {
  if (
    !event ||
    typeof event.name !== "string" ||
    typeof event.date !== "string" ||
    typeof event.seats !== "number" ||
    typeof event.category !== "string"
  ) {
    throw new Error(
      "Invalid event object. Required fields: name, date, seats, category.",
    );
  }

  events.push({ ...event });
  return `Event added: ${event.name}`;
}

function registerUser(eventName, userName) {
  if (typeof eventName !== "string" || eventName.trim() === "") {
    throw new Error("Event name is required.");
  }
  if (typeof userName !== "string" || userName.trim() === "") {
    throw new Error("User name is required.");
  }

  const event = events.find((item) => item.name === eventName);
  if (!event) {
    throw new Error(`Event not found: ${eventName}`);
  }
  if (event.seats <= 0) {
    throw new Error(`No seats available for ${event.name}`);
  }

  event.seats -= 1;
  registrations.push({ eventName, userName, date: new Date().toISOString() });
  return `User ${userName} registered for ${event.name}`;
}

function filterEventsByCategory(category) {
  return events.filter((event) => event.category === category);
}

function searchEvents(predicate) {
  return events.filter(predicate);
}

function createCategoryRegistrationTracker(category) {
  let totalRegistrations = 0;

  return {
    track() {
      totalRegistrations += 1;
    },
    getTotal() {
      return totalRegistrations;
    },
    register(eventName, userName) {
      const event = events.find(
        (item) => item.name === eventName && item.category === category,
      );
      if (!event) {
        throw new Error(`No ${category} event found with name ${eventName}`);
      }
      const result = registerUser(eventName, userName);
      this.track();
      return result;
    },
  };
}

// Example usage:
const workshopTracker = createCategoryRegistrationTracker("Workshop");

try {
  console.log(
    addEvent({
      name: "Design Studio",
      date: "2026-11-15",
      seats: 20,
      category: "Workshop",
    }),
  );

  console.log(workshopTracker.register("Design Studio", "Aisha"));
  console.log(`Workshop registrations: ${workshopTracker.getTotal()}`);

  const availableMusic = searchEvents(
    (event) => event.category === "Music" && event.seats > 0,
  );
  console.log("Available music events:", availableMusic);
} catch (error) {
  console.error(error.message);
}
