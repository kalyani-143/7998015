const events = [
  {
    name: "Music Festival",
    date: "2026-07-20",
    seats: 50,
  },
  {
    name: "Past Event",
    date: "2025-01-01",
    seats: 20,
  },
  {
    name: "Workshop",
    date: "2026-08-10",
    seats: 0,
  },
];

const today = new Date();

function isUpcomingAndAvailable(event) {
  if (
    !event ||
    typeof event.name !== "string" ||
    typeof event.date !== "string" ||
    typeof event.seats !== "number"
  ) {
    return false;
  }

  const eventDate = new Date(event.date);
  if (isNaN(eventDate)) {
    return false;
  }

  return eventDate > today && event.seats > 0;
}

const visibleEvents = events.filter((event) => isUpcomingAndAvailable(event));

if (visibleEvents.length === 0) {
  console.log("No upcoming events with available seats.");
} else {
  visibleEvents.forEach((event, index) => {
    console.log(
      `${index + 1}. ${event.name} — ${event.date} (${event.seats} seats left)`,
    );
  });
}

function register(eventName) {
  try {
    if (typeof eventName !== "string" || eventName.trim() === "") {
      throw new Error("Invalid event name");
    }

    const event = events.find((item) => item.name === eventName);
    if (!event) {
      throw new Error(`Event not found: ${eventName}`);
    }

    const eventDate = new Date(event.date);
    if (isNaN(eventDate)) {
      throw new Error(`Invalid event date for ${event.name}`);
    }

    if (eventDate <= today) {
      throw new Error(`Cannot register for past event: ${event.name}`);
    }

    if (event.seats <= 0) {
      throw new Error(`No seats available for ${event.name}`);
    }

    event.seats -= 1;
    console.log(
      `Registered successfully for ${event.name}. Seats remaining: ${event.seats}`,
    );
  } catch (error) {
    console.error(`Registration failed: ${error.message}`);
  }
}
