function Event(name, date, seats) {
  this.name = name;
  this.date = new Date(date);
  this.seats = seats;
}

Event.prototype.checkAvailability = function () {
  const now = new Date();
  const isFutureEvent = this.date > now;
  const hasSeats = typeof this.seats === "number" && this.seats > 0;
  return isFutureEvent && hasSeats;
};

Event.prototype.register = function () {
  if (!this.checkAvailability()) {
    return `Cannot register for ${this.name}. Event is either full or already passed.`;
  }

  this.seats -= 1;
  return `Registered for ${this.name}. Seats remaining: ${this.seats}`;
};

const eventList = [
  new Event("Music Festival", "2026-07-20", 50),
  new Event("Past Event", "2025-01-01", 20),
  new Event("Workshop", "2026-08-10", 0),
];

eventList.forEach((event) => {
  console.log(`Event: ${event.name}`);
  console.log(`Available: ${event.checkAvailability()}`);
  console.log("Properties and values:");

  Object.entries(event).forEach(([key, value]) => {
    console.log(`  ${key}: ${value}`);
  });

  console.log("-----");
});

// Example usage:
console.log(eventList[0].register());
console.log(eventList[1].register());
console.log(eventList[2].register());
