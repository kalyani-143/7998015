// Sample Events

const events = [
  {
    id: 1,
    name: "Music Festival",
    date: "2026-06-15",
    seats: 50,
  },
  {
    id: 2,
    name: "Baking Workshop",
    date: "2026-07-10",
    seats: 30,
  },
];

const isBrowser =
  typeof window !== "undefined" && typeof document !== "undefined";

function getEventContainer() {
  if (!isBrowser) {
    return null;
  }

  return document.querySelector("#eventContainer");
}

function createEventCard(event) {
  const card = document.createElement("div");
  card.classList.add("event-card");

  const title = document.createElement("h3");
  title.textContent = event.name;

  const dateText = document.createElement("p");
  dateText.textContent = `Date: ${event.date}`;

  const seatsText = document.createElement("p");
  seatsText.id = `seats-${event.id}`;
  seatsText.textContent = `Seats Available: ${event.seats}`;

  const registerButton = document.createElement("button");
  registerButton.textContent = "Register";
  registerButton.classList.add("register-button");
  registerButton.addEventListener("click", () => registerEvent(event.id));
  registerButton.disabled = event.seats <= 0;

  const cancelButton = document.createElement("button");
  cancelButton.textContent = "Cancel";
  cancelButton.classList.add("cancel-button");
  cancelButton.addEventListener("click", () => cancelRegistration(event.id));

  card.append(title, dateText, seatsText, registerButton, cancelButton);
  return card;
}

function displayEvents() {
  const eventContainer = getEventContainer();
  if (!eventContainer) {
    console.warn("Cannot display events: DOM is not available.");
    return;
  }

  eventContainer.innerHTML = "";

  events.forEach((event) => {
    const eventCard = createEventCard(event);
    eventContainer.appendChild(eventCard);
  });
}

function registerEvent(id) {
  const event = events.find((e) => e.id === id);
  if (!event) {
    return;
  }

  if (event.seats > 0) {
    event.seats -= 1;
    updateUI(id);
    alert("Registration Successful");
  } else {
    alert("No Seats Available");
  }
}

function cancelRegistration(id) {
  const event = events.find((e) => e.id === id);
  if (!event) {
    return;
  }

  event.seats += 1;
  updateUI(id);
  alert("Registration Cancelled");
}

function updateUI(id) {
  if (!isBrowser) {
    return;
  }

  const event = events.find((e) => e.id === id);
  if (!event) {
    return;
  }

  const seatElement = document.querySelector(`#seats-${id}`);
  if (seatElement) {
    seatElement.textContent = `Seats Available: ${event.seats}`;
  }

  const card = seatElement ? seatElement.closest(".event-card") : null;
  const registerButton = card ? card.querySelector(".register-button") : null;
  if (registerButton) {
    registerButton.disabled = event.seats <= 0;
  }
}

if (isBrowser) {
  document.addEventListener("DOMContentLoaded", displayEvents);
} else {
  console.warn("Skipping event rendering because document is not defined.");
}
